package com.factory.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.factory.domain.Marca;
import com.factory.repository.MarcaRepository;

@Service
public class MarcaService {
	
	private MarcaRepository marcaRepository;

	@Autowired
	public MarcaService(MarcaRepository marcaRepository) {
		this.marcaRepository = marcaRepository;
	}
	
	public Marca createMarca(Integer idMarca, String nombre, String estado){
		if(!marcaRepository.exists(idMarca)){
			marcaRepository.save(new Marca(idMarca, nombre, estado));
		}
		return null;
	}
	
	public Iterable<Marca> lookup(){
		return marcaRepository.findAll();
	}
	
	public long total(){
		return marcaRepository.count();
	}
}
