package com.factory.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.factory.domain.Modelo;
import com.factory.repository.ModeloRepository;

@Service
public class ModeloService {

	private ModeloRepository modeloRepository;

	@Autowired
	public ModeloService(ModeloRepository modeloRepository) {
		this.modeloRepository = modeloRepository;
	}
	
	public Modelo createModelo(Integer idModelo, String nombre, String estado){
		if(!modeloRepository.exists(idModelo)){
			modeloRepository.save(new Modelo(idModelo, nombre, estado));
		}
		return null;
	}
	
	public Iterable<Modelo> lookup(){
		return modeloRepository.findAll();
	}
	
	public long total(){
		return modeloRepository.count();
	}
	
	
}
