package com.factory.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.factory.domain.Bodega;
import com.factory.domain.Categoria;
import com.factory.domain.Marca;
import com.factory.domain.Modelo;
import com.factory.domain.Producto;
import com.factory.repository.BodegaRepository;
import com.factory.repository.CategoriaRepository;
import com.factory.repository.MarcaRepository;
import com.factory.repository.ModeloRepository;
import com.factory.repository.ProductoRepository;

@Service
public class ProductoService {

	private ProductoRepository productoRepository;
	private CategoriaRepository categoriaRepository;
	private MarcaRepository marcaRepository;
	private ModeloRepository modeloRepository;
	private BodegaRepository bodegaRepository;
	
	@Autowired
	public ProductoService(ProductoRepository productoRepository, CategoriaRepository categoriaRepository,
			MarcaRepository marcaRepository, ModeloRepository modeloRepository, BodegaRepository bodegaRepository) {
		this.productoRepository = productoRepository;
		this.categoriaRepository = categoriaRepository;
		this.marcaRepository = marcaRepository;
		this.modeloRepository = modeloRepository;
		this.bodegaRepository = bodegaRepository;
	}

	public Producto createProducto(Integer idProducto, 
								   String  nombre, 
								   Double  precioCompra,
								   Double precioVenta, Categoria categoria, Marca marca, Modelo modelo, Bodega bodega){
		
		Categoria categoriaData = categoriaRepository.findOne(categoria.getIdCategoria());
		Marca marcaData = marcaRepository.findOne(marca.getIdMarca());
		Modelo modeloData = modeloRepository.findOne(modelo.getIdModelo());
		Bodega bodegaData = bodegaRepository.findOne(bodega.getIdBodega());
		
		if(categoriaData == null){
			throw new RuntimeException(("No existe la categoria con el id "+categoria.getIdCategoria()));
		}
		
		if(marcaData == null){
			throw new RuntimeException(("No existe la categoria con el id "+marca.getIdMarca()));
		}
		
		if(modeloData == null){
			throw new RuntimeException(("No existe la categoria con el id "+modelo.getIdModelo()));
		}
		
		if(bodegaData == null){
			throw new RuntimeException(("No existe la categoria con el id "+bodega.getIdBodega()));
		}
		
		
		return productoRepository.save(new Producto(idProducto, nombre, precioCompra, precioVenta, 
													categoria, marca, modelo, bodega));
		
	}
	
	public Iterable<Producto> lookup(){
		return productoRepository.findAll();
	}
	
	public long total(){
		return productoRepository.count();
	}
	
	
	
}
