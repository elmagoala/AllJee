package com.factory.services;

import org.springframework.stereotype.Service;

import com.factory.domain.Bodega;
import com.factory.repository.BodegaRepository;

@Service
public class BodegaService {

	private BodegaRepository bodegaRepository;

	public BodegaService(BodegaRepository bodegaRepository) {
		this.bodegaRepository = bodegaRepository;
	}
	
	public Bodega createBodega(Integer idBodega, String nombre){
		if(!bodegaRepository.exists(idBodega)){
			bodegaRepository.save(new Bodega(idBodega, nombre));
		}
		return null;
	}
	
	public Iterable<Bodega> lookup(){
		return bodegaRepository.findAll();
	}
	
	public long total(){
		return bodegaRepository.count();
	}
}
