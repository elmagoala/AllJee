package com.factory.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.factory.domain.Categoria;
import com.factory.repository.CategoriaRepository;

@Service
public class CategoriaService {
	
	private CategoriaRepository categoriaRepository;

	@Autowired
	public CategoriaService(CategoriaRepository categoriaRepository) {
		this.categoriaRepository = categoriaRepository;
	}
	
	public Categoria createCategoria(Integer idCategoria, String nombre, String estado){
		if(!categoriaRepository.exists(idCategoria)){
			categoriaRepository.save(new Categoria(idCategoria,nombre,estado));
		}
		return null;
	}
	
	public Iterable<Categoria> lookup(){
		return categoriaRepository.findAll();
	}
	
	public long total(){
		return categoriaRepository.count();
	}

}
