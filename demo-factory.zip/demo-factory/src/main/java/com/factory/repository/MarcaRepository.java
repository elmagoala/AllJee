package com.factory.repository;

import org.springframework.data.repository.CrudRepository;

import com.factory.domain.Marca;

public interface MarcaRepository extends CrudRepository<Marca, Integer> {

}
