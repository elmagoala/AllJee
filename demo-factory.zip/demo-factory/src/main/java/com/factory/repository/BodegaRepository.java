package com.factory.repository;

import org.springframework.data.repository.CrudRepository;

import com.factory.domain.Bodega;

public interface BodegaRepository extends CrudRepository<Bodega, Integer>{

}
