package com.factory.repository;

import org.springframework.data.repository.CrudRepository;

import com.factory.domain.Producto;

public interface ProductoRepository extends CrudRepository<Producto, Integer> {

}
