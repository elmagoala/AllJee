package com.factory.repository;

import org.springframework.data.repository.CrudRepository;

import com.factory.domain.Categoria;

public interface CategoriaRepository extends CrudRepository<Categoria, Integer> {

}
