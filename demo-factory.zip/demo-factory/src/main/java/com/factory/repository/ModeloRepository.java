package com.factory.repository;

import org.springframework.data.repository.CrudRepository;

import com.factory.domain.Modelo;

public interface ModeloRepository extends CrudRepository<Modelo, Integer>{

}
