package com.factory.demofactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.factory.services.BodegaService;
import com.factory.services.CategoriaService;
import com.factory.services.MarcaService;
import com.factory.services.ModeloService;
import com.factory.services.ProductoService;

@SpringBootApplication
public class DemoFactoryApplication implements CommandLineRunner{
	
	@Autowired
	private CategoriaService categoriaService;
	
	@Autowired
	private MarcaService marca;
	
	@Autowired
	private ModeloService modelo;
	
	@Autowired
	private BodegaService bodega;
	
	@Autowired
	private ProductoService producto;

	public static void main(String[] args) {
		SpringApplication.run(DemoFactoryApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		
		categoriaService.createCategoria(1, "Limpieza", "A");
		marca.createMarca(1, "boom", "A");
		modelo.createModelo(1, "galon", "A");
		bodega.createBodega(1, "babahoyo");
		
		categoriaService.lookup().forEach(categoria -> System.out.println(categoria));
		
		//Categoria categoriaData = categoria.
		//producto.createProducto(new Integer(1), "galon", new Double(10.95), new Double(11.95), categoria, marca, modelo, bodega);
		
	}
}
